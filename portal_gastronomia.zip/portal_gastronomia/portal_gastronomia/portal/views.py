from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect, render

from . import rut as rut_utils

# slug -> (título, subtítulo). El menú y el contenido se arman en JavaScript
# según el rol guardado en localStorage.
PAGINAS = {
    "inicio": ("Inicio", "Resumen general de tu sede"),
    "consumo": (
        "Consumo por Curso y Receta",
        "Vista consolidada para Administrador/a de sede y consulta de Consumo para Docente",
    ),
    "presupuesto": (
        "Presupuesto actual de Gastronomía",
        "Vista exclusiva para Administrador/a de sede",
    ),
    "insumos": (
        "Inventario y Movimiento de Insumos",
        "Plataforma de Control de Inventario y Operaciones Gastronómicas",
    ),
    "utensilios": (
        "Estado de utensilios y equipos",
        "Seguimiento por sede con historial de préstamos y devoluciones",
    ),
    "estudiantes": (
        "Registros de estudiantes",
        "Reportes de entrega de clase enviados por los estudiantes",
    ),
    "registro-utensilios": (
        "Módulo Estudiante: Reporte de Entrega de Clase",
        "Plataforma de Control de Inventario y Operaciones Gastronómicas",
    ),
}


def index(request):
    return redirect("login")


def login_view(request):
    return render(request, "portal/login.html")


def registro_view(request):
    return render(request, "portal/registro.html")


def panel(request, page):
    titulo, subtitulo = PAGINAS[page]
    return render(
        request,
        "portal/panel.html",
        {"page": page, "titulo": titulo, "subtitulo": subtitulo},
    )


def validar_rut(request):
    """GET /api/validar-rut/?rut=12.345.678-5 -> {valido, rut, formateado}"""
    valor = request.GET.get("rut", "")
    return JsonResponse(
        {
            "valido": rut_utils.es_valido(valor),
            "rut": rut_utils.limpiar(valor),
            "formateado": rut_utils.formatear(valor),
        }
    )
def error_404(request, exception=None):
    return HttpResponse("Página no encontrada.", status=404)

def error_500(request):
    return HttpResponse("Ocurrió un error interno.", status=500)