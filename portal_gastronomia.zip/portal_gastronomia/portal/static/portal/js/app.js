/* Portal-Gastronomía · lógica del cliente (datos en localStorage) */
(() => {
'use strict';

/* ================= Utilidades ================= */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const pad = (n) => String(n).padStart(2, '0');
const MESES = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
const MESES_L = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
const isoDay = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const isoLocal = (d = new Date()) => `${isoDay(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return isoDay(d); };
const atTime = (h, m = 0) => { const d = new Date(); d.setHours(h, m, 0, 0); return isoLocal(d); };
const fmtDate = (iso) => { if (!iso) return '—'; const [y, m, d] = iso.slice(0, 10).split('-'); return `${d}/${m}/${y}`; };
const fmtShort = (iso) => { if (!iso) return '—'; const d = new Date(iso); return `${pad(d.getDate())} ${MESES[d.getMonth()]}, ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const fmtHour = (iso) => { const d = new Date(iso); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const fmtFull = (iso) => { const d = new Date(iso); return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} · ${fmtHour(iso)}`; };
const fmtNum = (n, dec = 1) => Number(n).toLocaleString('es-CL', { minimumFractionDigits: 0, maximumFractionDigits: dec });
const clp = (n) => `${n < 0 ? '-' : ''}$${Math.abs(Math.round(n)).toLocaleString('es-CL')} CLP`;
const clpSigned = (n) => `${n < 0 ? '-' : '+'}$${Math.abs(Math.round(n)).toLocaleString('es-CL')} CLP`;

function toast(msg) {
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2600);
}

/* ---- RUT ---- */
const cleanRut = (v) => String(v || '').replace(/[.\s]/g, '').toUpperCase();
function rutDV(body) {
  let s = 0, m = 2;
  for (let i = body.length - 1; i >= 0; i--) { s += Number(body[i]) * m; m = m === 7 ? 2 : m + 1; }
  const r = 11 - (s % 11);
  return r === 11 ? '0' : r === 10 ? 'K' : String(r);
}
function validRut(v) {
  const m = /^(\d{7,8})-([\dK])$/.exec(cleanRut(v));
  return !!m && rutDV(m[1]) === m[2];
}
function formatRut(v) {
  const m = /^(\d{7,8})-([\dK])$/.exec(cleanRut(v));
  return m ? `${Number(m[1]).toLocaleString('es-CL')}-${m[2]}` : cleanRut(v);
}

/* ---- Hash de contraseña (SHA-256 si el navegador lo permite) ---- */
async function hashPass(p) {
  if (window.crypto && crypto.subtle) {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('pg:' + p));
    return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
  }
  return 'b64:' + btoa(unescape(encodeURIComponent('pg:' + p)));
}

/* ================= Almacenamiento (localStorage) ================= */
const K = {
  users: 'pg_usuarios', session: 'pg_sesion', inv: 'pg_inventario', mov: 'pg_movimientos',
  ent: 'pg_entregas', loans: 'pg_prestamos', catalog: 'pg_catalogo', reports: 'pg_reportes_estudiantes',
  budget: 'pg_presupuesto', consumo: 'pg_consumo', seeded: 'pg_semilla_v1',
};
const DB = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { toast('No se pudo guardar en el navegador (almacenamiento lleno).'); } },
};

/* ================= Roles y navegación ================= */
const ROLES = {
  admin: {
    label: 'Administrador/a de sede',
    attrib: 'Acceso a Inicio, Consumo y Presupuesto de su sede. Puede revisar el consolidado por curso y receta, y administrar el presupuesto de Gastronomía.',
  },
  cocina: {
    label: 'Encargado/a de cocina',
    attrib: 'Acceso ilimitado a registrar insumos, utensilios y equipos de su sede. Puede aprobar devoluciones y dar de baja mermas.',
  },
  docente: {
    label: 'Docente',
    attrib: 'Puede consultar Consumo para revisar recetas, insumos y clases asignadas.',
  },
  estudiante: {
    label: 'Estudiante',
    attrib: 'Puede declarar utensilios y equipos prestados y reportar la entrega de clase, incluyendo daños.',
  },
};
const ICON = {
  cube: '<path d="M12 2l9 5v10l-9 5-9-5V7z"/><path d="M12 12l9-5M12 12v10M12 12L3 7"/>',
  trend: '<polyline points="3 17 9 11 13 15 21 7"/><polyline points="15 7 21 7 21 13"/>',
  card: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  archive: '<rect x="3" y="3" width="18" height="5" rx="1"/><path d="M5 8v12h14V8M10 12h4"/>',
  book: '<path d="M2 4h7a3 3 0 013 3v14a2 2 0 00-2-2H2z"/><path d="M22 4h-7a3 3 0 00-3 3v14a2 2 0 012-2h8z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  download: '<path d="M12 4v11M7 11l5 5 5-5M4 20h16"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  logout: '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>',
};
const svg = (n) => `<svg class="ic" viewBox="0 0 24 24">${ICON[n]}</svg>`;
const NAV = {
  admin: [['inicio', 'Inicio', 'cube'], ['consumo', 'Consumo', 'trend'], ['presupuesto', 'Presupuesto', 'card']],
  cocina: [['inicio', 'Inicio', 'cube'], ['insumos', 'Registros de insumos', 'archive'], ['utensilios', 'Estado de utensilios y equipos', 'book'], ['estudiantes', 'Registros de estudiantes', 'book']],
  docente: [['inicio', 'Inicio', 'cube'], ['consumo', 'Consumo', 'trend']],
  estudiante: [['inicio', 'Inicio', 'cube'], ['registro-utensilios', 'Registro de utensilios y equipos', 'archive']],
};
const REGIONES = {
  'Región Metropolitana': { corta: 'RM', sedes: ['Santiago Centro', 'Maipú', 'Providencia', 'Puente Alto'] },
  'Valparaíso': { corta: 'V', sedes: ['Viña del Mar', 'Valparaíso'] },
  'Biobío': { corta: 'VIII', sedes: ['Concepción', 'Los Ángeles'] },
  'Araucanía': { corta: 'IX', sedes: ['Temuco'] },
};

/* ================= Datos de ejemplo (se crean una sola vez) ================= */
async function seed() {
  if (DB.get(K.seeded, false)) return;
  const mk = async (nombre, apellido, rutBody, pass, rol) => ({
    id: uid(), nombre, apellido, rut: `${rutBody}-${rutDV(rutBody)}`, pass: await hashPass(pass),
    region: 'Región Metropolitana', sede: 'Santiago Centro', rol, documento: { nombre: 'credencial.pdf', size: 120000 },
    creadoEn: new Date().toISOString(), semilla: true,
  });
  DB.set(K.users, [
    await mk('Eugenia', 'Rojas', '11111111', 'Admin1234', 'admin'),
    await mk('Sonía', 'Muñoz', '22222222', 'Cocina1234', 'cocina'),
    await mk('Constanza', 'Almonacid', '33333333', 'Estudiante1234', 'estudiante'),
    await mk('Pablo', 'Fuentes', '44444444', 'Docente1234', 'docente'),
  ]);

  const inv = (nombre, categoria, stock, min, unidad, dias, responsable, estado) =>
    ({ id: uid(), nombre, categoria, stock, min, unidad, venc: addDays(dias), responsable, estado });
  DB.set(K.inv, [
    inv('Harina de Fuerza Trigo', 'Panadería', 45, 10, 'Kg', 30, 'Carlos Valenzuela', 'Disponible'),
    inv('Mantequilla con Sal Colun', 'Lácteos/Crema', 4.5, 8, 'Kg', 10, 'Carlos Valenzuela', 'Stock Bajo'),
    inv('Pisco de Cocina 35° Tres Erres', 'Licores', 0, 2, 'Lts', -20, 'Sonía Muñoz', 'Vencido'),
    inv('Crema de Leche Soprole', 'Lácteos/Crema', 28, 12, 'Lts', 14, 'Sonía Muñoz', 'Disponible'),
    inv('Azúcar Flor Iansa', 'Panadería', 12, 6, 'Kg', 45, 'Carlos Valenzuela', 'Disponible'),
    inv('Queso Crema Philadelphia', 'Lácteos/Crema', 6, 8, 'Kg', -23, 'Sonía Muñoz', 'Vencido'),
  ]);
  const t = (h, m) => { const d = new Date(); d.setHours(h, m, 0, 0); return d.toISOString(); };
  DB.set(K.mov, [
    { id: uid(), tipo: 'entrada', titulo: 'Entrada de stock', detalle: 'Harina de Fuerza Trigo · 10.0 kg', valor: '+10.0', ts: t(9, 30) },
    { id: uid(), tipo: 'alerta', titulo: 'Alerta de stock bajo', detalle: 'Mantequilla con Sal Colun · 4.5 kg', valor: 'Bajo', ts: t(9, 10) },
    { id: uid(), tipo: 'vencido', titulo: 'Producto vencido', detalle: 'Pisco de Cocina · 0.0 Lts', valor: 'Vencido', ts: t(8, 50) },
  ]);
  DB.set(K.ent, [
    { id: uid(), destino: 'cocina', detalle: 'Crema de Leche · 4.0 Lts', ts: t(9, 20) },
    { id: uid(), destino: 'pastelería', detalle: 'Azúcar Flor · 2.0 kg', ts: t(8, 45) },
    { id: uid(), destino: 'barra', detalle: 'Jugo de Naranja · 6.0 Lts', ts: t(8, 10) },
  ]);

  DB.set(K.catalog, [
    { codigo: 'UTE-SGC-004', nombre: 'Cuchillo Chef Profesional 8"', tipo: 'Utensilio' },
    { codigo: 'EQP-SGC-102', nombre: 'Balanza Digital de Precisión', tipo: 'Equipo' },
    { codigo: 'EQP-SGC-088', nombre: 'Batidora Planetaria 20 Lts', tipo: 'Equipo' },
    { codigo: 'UTE-SGC-145', nombre: 'Sartén Antiadherente 26cm', tipo: 'Utensilio' },
    { codigo: 'UTE-SGC-201', nombre: 'Termómetro de Cocina', tipo: 'Utensilio' },
    { codigo: 'UTE-SGC-310', nombre: 'Cuchillo Medio Golpe Arcos', tipo: 'Utensilio' },
    { codigo: 'EQP-SGC-215', nombre: 'Balanza de Gramaje Ohaus', tipo: 'Equipo' },
    { codigo: 'UTE-SGC-322', nombre: 'Sartén de Teflón Profesional 24cm', tipo: 'Utensilio' },
    { codigo: 'UTE-SGC-330', nombre: 'Espátula de Silicona', tipo: 'Utensilio' },
    { codigo: 'EQP-SGC-240', nombre: 'Horno Convector Portátil', tipo: 'Equipo' },
  ]);
  const loan = (codigo, nombre, tipo, usuario, rut, estado, dano = '', devuelto = false) => ({
    id: uid(), codigo, nombre, tipo, usuario, rut, estado, dano,
    prestamo: atTime(8, 30), devPrevista: atTime(13, 0), devReal: devuelto ? atTime(12, 50) : null,
  });
  DB.set(K.loans, [
    loan('UTE-SGC-004', 'Cuchillo Chef Profesional 8"', 'Utensilio', 'Andrés Silva Valdés', '19.345.102-3', 'Pendiente'),
    loan('EQP-SGC-102', 'Balanza Digital de Precisión', 'Equipo', 'Fernanda Gómez', '20.111.222-3', 'Devuelto', '', true),
    loan('EQP-SGC-088', 'Batidora Planetaria 20 Lts', 'Equipo', 'Andrés Silva Valdés', '19.345.102-3', 'Pendiente'),
    loan('UTE-SGC-145', 'Sartén Antiadherente 26cm', 'Utensilio', 'Mario Soto', '18.777.888-9', 'Devuelto', '', true),
    loan('UTE-SGC-201', 'Termómetro de Cocina', 'Utensilio', 'Andrés Silva Valdés', '19.345.102-3', 'Con daños', 'Sensor descalibrado'),
    { ...loan('UTE-SGC-310', 'Cuchillo Medio Golpe Arcos', 'Utensilio', 'Constanza Almonacid', '33.333.333-3', 'Pendiente') },
    { ...loan('EQP-SGC-215', 'Balanza de Gramaje Ohaus', 'Equipo', 'Constanza Almonacid', '33.333.333-3', 'Pendiente') },
    { ...loan('UTE-SGC-322', 'Sartén de Teflón Profesional 24cm', 'Utensilio', 'Constanza Almonacid', '33.333.333-3', 'Pendiente') },
  ]);
  DB.set(K.reports, []);

  DB.set(K.budget, {
    inicial: 5000000,
    movs: [
      { id: uid(), ts: '2026-09-02T11:15', desc: 'Servicio Técnico Hornos Conectores Industriales', tipo: 'Egreso', monto: 420000, resp: 'Eugenia Rojas' },
      { id: uid(), ts: '2026-09-08T09:30', desc: 'Factura Proveedor Colun - Lácteos Prácticas', tipo: 'Egreso', monto: 780000, resp: 'Eugenia Rojas' },
      { id: uid(), ts: '2026-09-10T14:00', desc: 'Reposición de Caja Chica Operativa Sede', tipo: 'Ingreso', monto: 1500000, resp: 'Eugenia Rojas' },
      { id: uid(), ts: '2026-09-14T10:45', desc: 'Adquisición Chocolate de Repostería Bitter', tipo: 'Egreso', monto: 350000, resp: 'Sonía Muñoz' },
    ],
  });
  DB.set(K.consumo, {
    cursos: [
      { nombre: 'Pastelería Profesional IV', est: 32, rec: 6, kg: 124.8, color: '#0033a0' },
      { nombre: 'Panadería y Masa Madre', est: 28, rec: 4, kg: 96.4, color: '#16a34a' },
      { nombre: 'Repostería y Decoración', est: 24, rec: 5, kg: 88.2, color: '#d97706' },
    ],
    filas: [
      { curso: 'Pastelería IV', cursoFull: 'Pastelería Profesional IV', receta: 'Macarons de Frambuesa y Pistacho', fecha: '2026-03-12', insumos: 8, kg: 13.2, clases: 3, docente: 'Chef P. Fuentes', estado: 'Ajustado' },
      { curso: 'Panadería III', cursoFull: 'Panadería y Masa Madre', receta: 'Baguette Tradicional y Masa Madre', fecha: '2026-03-10', insumos: 6, kg: 29.8, clases: 4, docente: 'Chef J. Valenzuela', estado: 'Óptimo' },
      { curso: 'Repostería II', cursoFull: 'Repostería y Decoración', receta: 'Torta de Novia Tres Leches Chilena', fecha: '2026-03-05', insumos: 9, kg: 18.1, clases: 2, docente: 'Chef M. Almonacid', estado: 'Excedido' },
      { curso: 'Pastelería IV', cursoFull: 'Pastelería Profesional IV', receta: 'Milhojas de Manjar', fecha: '2026-03-19', insumos: 7, kg: 9.6, clases: 2, docente: 'Chef P. Fuentes', estado: 'Óptimo' },
      { curso: 'Repostería II', cursoFull: 'Repostería y Decoración', receta: 'Brazo de Reina con Frambuesa', fecha: '2026-03-26', insumos: 5, kg: 7.4, clases: 1, docente: 'Chef M. Almonacid', estado: 'Ajustado' },
    ],
  });
  DB.set(K.seeded, true);
}

/* ================= Sesión ================= */
const currentUser = () => {
  const s = DB.get(K.session, null); if (!s) return null;
  return DB.get(K.users, []).find((u) => u.rut === s.rut) || null;
};
const fullName = (u) => `${u.nombre} ${u.apellido}`.trim();
const sedeLabel = (u) => `${(REGIONES[u.region] || {}).corta || ''} - ${u.sede}`.replace(/^ - /, '');
function logout() { localStorage.removeItem(K.session); location.href = '/login/'; }

/* ================= Modal ================= */
function modal({ title, body, confirmText = 'Guardar', cancelText = 'Cancelar', onConfirm, hideCancel = false }) {
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.innerHTML = `<div class="modal" role="dialog" aria-modal="true"><h3>${esc(title)}</h3><div class="mbody">${body}</div>
    <p class="form-error" data-err hidden></p>
    <div class="actions">${hideCancel ? '' : `<button class="btn btn-outline" data-x>${esc(cancelText)}</button>`}<button class="btn btn-primary" data-ok>${esc(confirmText)}</button></div></div>`;
  document.body.appendChild(back);
  const close = () => back.remove();
  back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
  const x = $('[data-x]', back); if (x) x.onclick = close;
  $('[data-ok]', back).onclick = async () => {
    if (!onConfirm) return close();
    const r = await onConfirm(back);
    if (typeof r === 'string') { const er = $('[data-err]', back); er.textContent = r; er.hidden = false; return; }
    close();
  };
  const first = $('input,select,textarea', back); if (first) first.focus();
  return back;
}
const confirmBox = (msg, fn, txt = 'Confirmar') => modal({ title: 'Confirmar acción', body: `<p>${msg}</p>`, confirmText: txt, onConfirm: () => { fn(); } });
function download(name, text, type = 'text/csv;charset=utf-8') {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + text], { type }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
}
const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;

/* ================= Páginas de acceso ================= */
function bindEye() {
  $$('[data-toggle]').forEach((b) => b.addEventListener('click', () => {
    const i = $(b.dataset.toggle); i.type = i.type === 'password' ? 'text' : 'password';
  }));
}

function initLogin() {
  if (currentUser()) { location.replace('/inicio/'); return; }
  bindEye();
  if (new URLSearchParams(location.search).get('registrado')) {
    const f = $('#flash'); f.hidden = false;
    f.textContent = 'Solicitud enviada. Ya puedes iniciar sesión con tu RUT y contraseña.';
  }
  $('#btnSoporte').onclick = () => modal({
    title: 'Soporte y Ayuda', hideCancel: true, confirmText: 'Entendido',
    body: `<p>Ingresa con tu RUT (sin puntos, con guión) y tu contraseña. Si aún no tienes cuenta, solicita tu registro y adjunta tu documento de validación de rol.</p>
      <p style="margin-top:10px;color:#64748b;font-size:13px">Cuentas de ejemplo (contraseña entre paréntesis):<br>
      11111111-1 Administradora (Admin1234)<br>22222222-2 Encargada de cocina (Cocina1234)<br>
      33333333-3 Estudiante (Estudiante1234)<br>44444444-4 Docente (Docente1234)</p>`,
  });
  $('#btnOlvido').onclick = (e) => {
    e.preventDefault();
    modal({
      title: 'Restablecer contraseña', confirmText: 'Actualizar contraseña',
      body: `<p style="color:#64748b;font-size:13px;margin-bottom:12px">Como los datos viven en este navegador, puedes definir una nueva contraseña con tu RUT.</p>
        <div class="field"><label>RUT</label><input id="rsRut" placeholder="12345678-9"></div>
        <div class="field"><label>Nueva contraseña</label><input id="rsPass" type="password" placeholder="Mínimo 8 caracteres"></div>`,
      onConfirm: async (m) => {
        const rut = cleanRut($('#rsRut', m).value), p = $('#rsPass', m).value;
        const users = DB.get(K.users, []), u = users.find((x) => x.rut === rut);
        if (!u) return 'No existe una cuenta con ese RUT.';
        if (p.length < 8) return 'La contraseña debe tener al menos 8 caracteres.';
        u.pass = await hashPass(p); DB.set(K.users, users); toast('Contraseña actualizada.');
      },
    });
  };
  $('#loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = $('#loginError'); err.hidden = true;
    const rut = cleanRut($('#rut').value), pass = $('#password').value;
    if (!rut || !pass) { err.textContent = 'Ingresa tu RUT y contraseña.'; err.hidden = false; return; }
    const u = DB.get(K.users, []).find((x) => x.rut === rut);
    if (!u || u.pass !== await hashPass(pass)) { err.textContent = 'RUT o contraseña incorrectos.'; err.hidden = false; return; }
    DB.set(K.session, { rut: u.rut, desde: new Date().toISOString() });
    location.href = '/inicio/';
  });
}

function initRegistro() {
  bindEye();
  const region = $('#region'), sede = $('#sede'), roles = $('#roles'), attrib = $('#attrib');
  region.innerHTML = Object.keys(REGIONES).map((r) => `<option>${esc(r)}</option>`).join('');
  const fillSedes = () => { sede.innerHTML = REGIONES[region.value].sedes.map((s) => `<option>${esc(s)}</option>`).join(''); };
  region.onchange = fillSedes; fillSedes();

  let rol = 'cocina';
  const drawRoles = () => {
    roles.innerHTML = Object.entries(ROLES).map(([k, r]) =>
      `<label class="role ${k === rol ? 'on' : ''}"><input type="radio" name="rol" value="${k}" ${k === rol ? 'checked' : ''}><span class="bullet"></span>${esc(r.label)}<span class="tag-sel">ROL ELEGIDO</span></label>`).join('');
    attrib.innerHTML = `<b>ATRIBUCIONES DEL ROL SELECCIONADO:</b>${esc(ROLES[rol].attrib)}`;
    $$('input[name=rol]', roles).forEach((i) => i.onchange = () => { rol = i.value; drawRoles(); });
  };
  drawRoles();

  const rutIn = $('#rut');
  rutIn.addEventListener('blur', () => { if (validRut(rutIn.value)) rutIn.value = formatRut(rutIn.value); });

  let doc = null;
  const drop = $('#drop'), file = $('#documento');
  const setFile = (f) => {
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    if (!['pdf', 'png'].includes(ext)) return toast('Solo se aceptan archivos .PDF o .PNG.');
    if (f.size > 10 * 1024 * 1024) return toast('El archivo supera los 10MB.');
    doc = { nombre: f.name, size: f.size, tipo: f.type };
    drop.classList.add('on'); drop.classList.remove('err');
    $('#dropTitle').textContent = `${f.name} (${Math.max(1, Math.round(f.size / 1024))} KB)`;
  };
  file.onchange = () => file.files[0] && setFile(file.files[0]);
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('drag'); }));
  drop.addEventListener('drop', (e) => { const f = e.dataTransfer.files[0]; if (f) setFile(f); });

  $('#regForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = $('#regError'); err.hidden = true;
    $$('.err').forEach((n) => n.classList.remove('err'));
    const v = { nombre: $('#nombre').value.trim(), apellido: $('#apellido').value.trim(), rut: cleanRut(rutIn.value), pass: $('#password').value };
    const fail = (msg, el) => { err.textContent = msg; err.hidden = false; if (el) el.classList.add('err'); };
    if (!v.nombre) return fail('Ingresa tu nombre.', $('#nombre'));
    if (!v.apellido) return fail('Ingresa tu apellido.', $('#apellido'));
    let rutOk = validRut(v.rut);
    try { const r = await fetch('/api/validar-rut/?rut=' + encodeURIComponent(v.rut)); if (r.ok) rutOk = (await r.json()).valido; } catch { /* se usa la validación local */ }
    if (!rutOk) return fail('El RUT no es válido. Revisa el dígito verificador.', rutIn);
    if (v.pass.length < 8) return fail('La contraseña debe tener al menos 8 caracteres.', $('#password'));
    if (!doc) return fail('Sube tu documento de validación de rol (.PDF o .PNG).', drop) || drop.classList.add('err');
    const users = DB.get(K.users, []);
    if (users.some((u) => u.rut === v.rut)) return fail('Ya existe una cuenta con ese RUT.', rutIn);
    users.push({
      id: uid(), nombre: v.nombre, apellido: v.apellido, rut: v.rut, pass: await hashPass(v.pass),
      region: region.value, sede: sede.value, rol, documento: doc, creadoEn: new Date().toISOString(),
    });
    DB.set(K.users, users);
    location.href = '/login/?registrado=1';
  });
}

/* ================= Estructura del panel ================= */
function buildShell(u) {
  const cur = document.body.dataset.page;
  $('#sidebar').innerHTML = `
    <div class="brand"><h2>PANEL CONTROL</h2><small>Gestión de recursos</small></div>
    <div class="sede-box"><small>Sede activa</small><b>${esc(sedeLabel(u))}</b></div>
    <nav class="nav">${NAV[u.rol].map(([p, l, i]) => `<a href="/${p}/" class="${p === cur ? 'active' : ''}">${svg(i)}<span>${esc(l)}</span></a>`).join('')}</nav>
    <div class="user-box"><div class="avatar">${esc(u.nombre[0].toUpperCase())}</div>
      <div class="who"><b>${esc(u.nombre)}</b><small>${esc(ROLES[u.rol].label)}</small></div>
      <button class="logout" id="btnLogout" title="Cerrar sesión" aria-label="Cerrar sesión">${svg('logout')}</button></div>`;
  $('#btnLogout').onclick = () => confirmBox('¿Quieres cerrar tu sesión?', logout, 'Cerrar sesión');
  const toggle = () => document.body.classList.toggle('menu-open');
  $('#burger').onclick = toggle; $('#scrim').onclick = toggle;
}
const kpi = (label, value, cls, sub) => `<div class="kpi"><small>${esc(label)}</small><strong class="${cls}">${value}</strong><span>${sub}</span></div>`;
const tag = (estado) => {
  const c = { Disponible: 'green', Óptimo: 'green', Devuelto: 'green', Ingreso: 'green', 'Stock Bajo': 'amber', Pendiente: 'amber', Ajustado: 'amber', Vencido: 'red', 'Con daños': 'red', Excedido: 'red', Egreso: 'red' }[estado] || 'amber';
  return `<span class="tag t-${c}">${esc(estado)}</span>`;
};
const budgetStats = (b) => {
  const gastos = b.movs.filter((m) => m.tipo === 'Egreso').reduce((s, m) => s + m.monto, 0);
  const ingresos = b.movs.filter((m) => m.tipo === 'Ingreso').reduce((s, m) => s + m.monto, 0);
  return { gastos, ingresos, actual: b.inicial - gastos + ingresos };
};
const autoEstado = (it) => (it.venc && it.venc < isoDay() ? 'Vencido' : Number(it.stock) < Number(it.min) ? 'Stock Bajo' : 'Disponible');
const view = () => $('#view');

/* ================= Inicio ================= */
function pageInicio(u) {
  const inv = DB.get(K.inv, []), loans = DB.get(K.loans, []), reps = DB.get(K.reports, []);
  const b = DB.get(K.budget, { inicial: 0, movs: [] }), c = DB.get(K.consumo, { cursos: [], filas: [] });
  const pend = loans.filter((l) => l.estado !== 'Devuelto');
  const mine = loans.filter((l) => cleanRut(l.rut) === u.rut && l.estado === 'Pendiente');
  let cards = '';
  if (u.rol === 'admin') {
    cards = kpi('Presupuesto actual', clp(budgetStats(b).actual), 'c-blue', 'Disponible para compras inmediatas')
      + kpi('Insumos con stock bajo', inv.filter((i) => i.estado === 'Stock Bajo').length, 'c-orange', 'Requieren compra o reposición')
      + kpi('Préstamos sin devolver', pend.length, 'c-red', 'Utensilios y equipos en pañol')
      + kpi('Consumo total', `${fmtNum(c.cursos.reduce((s, x) => s + x.kg, 0))} kg`, 'c-green', 'Acumulado del período');
  } else if (u.rol === 'cocina') {
    cards = kpi('Insumos registrados', inv.length, 'c-blue', 'En el inventario activo')
      + kpi('Stock bajo', inv.filter((i) => i.estado === 'Stock Bajo').length, 'c-orange', 'Requieren reposición')
      + kpi('Vencidos', inv.filter((i) => i.estado === 'Vencido').length, 'c-red', 'No forman parte del stock')
      + kpi('Devoluciones pendientes', pend.length, 'c-green', `${reps.filter((r) => !r.verificado).length} reportes por verificar`);
  } else if (u.rol === 'docente') {
    cards = kpi('Cursos con consumo', c.cursos.length, 'c-blue', 'En el período vigente')
      + kpi('Recetas realizadas', c.cursos.reduce((s, x) => s + x.rec, 0), 'c-orange', 'Con historial de clases')
      + kpi('Consumo total', `${fmtNum(c.cursos.reduce((s, x) => s + x.kg, 0))} kg`, 'c-green', 'Acumulado del período');
  } else {
    cards = kpi('Elementos por devolver', mine.length, 'c-orange', 'Declarados a tu nombre')
      + kpi('Reportes enviados', reps.filter((r) => r.rut === u.rut).length, 'c-blue', 'Entregas de clase registradas');
  }
  const links = NAV[u.rol].filter((n) => n[0] !== 'inicio')
    .map(([p, l, i]) => `<a class="li" style="text-decoration:none" href="/${p}/"><span class="ico g">${svg(i)}</span><span class="txt"><b>${esc(l)}</b><small>Abrir sección</small></span></a>`).join('');
  view().innerHTML = `<div class="notice"><b>${svg('shield')} Bienvenido/a</b><span>Hola, ${esc(u.nombre)}. Ingresaste como ${esc(ROLES[u.rol].label)} en la sede ${esc(sedeLabel(u))}.</span></div>
    <div class="kpis">${cards}</div><div class="card"><h3>Accesos rápidos</h3>${links}</div>`;
}

/* ================= Insumos (Encargado/a de cocina) ================= */
function pageInsumos(u) {
  const v = view(); v.classList.add('flush');
  const st = { q: '', cat: 'Todas', est: 'Todos', sel: null };
  const CATS = ['Panadería', 'Lácteos/Crema', 'Licores', 'Abarrotes', 'Frutas y Verduras', 'Carnes y Pescados'];
  const UNITS = ['Kg', 'Lts', 'Un'], ESTS = ['Disponible', 'Stock Bajo', 'Vencido'];
  v.innerHTML = `<div class="layout"><div class="content">
    <div class="kpis" id="iKpis"></div>
    <div class="card"><div class="toolbar"><h3 style="margin:0">Inventario Activo</h3>
      <div class="search">${svg('search')}<input id="iQ" placeholder="Buscar por insumo, categoría o responsable..."></div>
      <select id="iCat"></select><select id="iEst"></select>
      <button class="btn btn-primary btn-sm" id="iNew">${svg('plus')} Nuevo insumo</button></div>
      <div class="chips" id="iChips" style="margin-top:16px"></div>
      <div class="tbl-wrap" style="margin:0"><table><thead><tr><th>Insumo</th><th>Categoría</th><th>Stock Actual</th><th>Stock Mín.</th><th>Vencimiento</th><th>Estado</th><th></th></tr></thead><tbody id="iBody"></tbody></table></div></div>
    <div class="two-col"><div class="card"><h3>Historial de Movimientos</h3><div id="iMov"></div></div><div class="card"><h3>Entregas Realizadas</h3><div id="iEnt"></div></div></div>
    </div><aside class="side" id="iSide"></aside></div>`;
  $('#iCat').innerHTML = ['Todas', ...CATS].map((c) => `<option value="${esc(c)}">Categoría: ${esc(c)}</option>`).join('');
  $('#iEst').innerHTML = ['Todos', ...ESTS].map((c) => `<option value="${esc(c)}">Estado: ${esc(c)}</option>`).join('');

  const addMov = (tipo, titulo, detalle, valor) => {
    const m = DB.get(K.mov, []); m.push({ id: uid(), tipo, titulo, detalle, valor, ts: new Date().toISOString() }); DB.set(K.mov, m);
  };
  function drawTop() {
    const inv = DB.get(K.inv, []), ent = DB.get(K.ent, []);
    const n = (e) => inv.filter((i) => i.estado === e).length;
    const hoy = ent.filter((e) => isoDay(new Date(e.ts)) === isoDay()).length;
    $('#iKpis').innerHTML = kpi('Stock actual', `${inv.length - n('Vencido')} ítems`, 'c-blue', 'Disponibles para producción')
      + kpi('Stock mínimo', `${n('Stock Bajo')} ítems`, 'c-orange', 'Configurado para alertas')
      + kpi('Vencidos', `${n('Vencido')} ítems`, 'c-red', 'No forman parte del stock disponible')
      + kpi('Entregas hoy', `${hoy} entregas`, 'c-green', 'Actualizan stock automáticamente');
    $('#iChips').innerHTML = `<div class="chip"><b>DISPONIBLE</b><strong>${n('Disponible')} items</strong>Dentro del rango operativo</div>
      <div class="chip warn"><b>STOCK BAJO</b><strong>${n('Stock Bajo')} items</strong>Requiere compra o reposición</div>
      <div class="chip bad"><b>VENCIDOS</b><strong>${n('Vencido')} items</strong>No forman parte del stock disponible</div>`;
  }
  function drawTable() {
    const q = st.q.toLowerCase();
    const rows = DB.get(K.inv, []).filter((i) =>
      (st.cat === 'Todas' || i.categoria === st.cat) && (st.est === 'Todos' || i.estado === st.est)
      && (!q || `${i.nombre} ${i.categoria} ${i.responsable}`.toLowerCase().includes(q)));
    $('#iBody').innerHTML = rows.length ? rows.map((i) => `<tr class="clickable ${st.sel === i.id ? 'sel' : ''}" data-id="${i.id}">
      <td><b>${esc(i.nombre)}</b></td><td>${esc(i.categoria)}</td><td class="num">${fmtNum(i.stock)}</td><td class="num">${fmtNum(i.min)}</td>
      <td>${fmtDate(i.venc)}</td><td>${tag(i.estado)}</td><td><button class="btn-link" data-edit="${i.id}">Editar</button></td></tr>`).join('')
      : `<tr><td colspan="7" class="empty">No hay insumos que coincidan con la búsqueda.</td></tr>`;
  }
  function drawLists() {
    const sym = { entrada: ['g', '+'], alerta: ['a', '!'], vencido: ['r', '×'], salida: ['g', '–'] };
    const movs = DB.get(K.mov, []).sort((a, b) => b.ts.localeCompare(a.ts)).slice(0, 5);
    $('#iMov').innerHTML = movs.length ? movs.map((m) => { const [c, s] = sym[m.tipo] || ['g', '+']; const vc = { g: 'c-green', a: 'c-orange', r: 'c-red' }[c];
      return `<div class="li"><span class="ico ${c}">${s}</span><span class="txt"><b>${esc(m.titulo)}</b><small>${esc(m.detalle)}</small></span><span class="val ${vc}">${esc(m.valor)}</span></div>`; }).join('') : '<p class="empty">Sin movimientos.</p>';
    const ents = DB.get(K.ent, []).sort((a, b) => b.ts.localeCompare(a.ts)).slice(0, 5);
    $('#iEnt').innerHTML = ents.length ? ents.map((e) => `<div class="li"><span class="ico g">✓</span><span class="txt"><b>Entrega a ${esc(e.destino)}</b><small>${esc(e.detalle)}</small></span><span class="val c-green">${fmtHour(e.ts)}</span></div>`).join('') : '<p class="empty">Sin entregas registradas.</p>';
  }
  function drawSide() {
    const side = $('#iSide'), inv = DB.get(K.inv, []), isNew = st.sel === 'new';
    const it = isNew ? { nombre: '', categoria: CATS[0], stock: 0, min: 0, unidad: 'Kg', venc: addDays(30), responsable: fullName(u), estado: 'Disponible' } : inv.find((x) => x.id === st.sel);
    if (!it) { side.innerHTML = '<h3>Panel de Edición</h3><p class="sub">Selecciona un insumo de la tabla para editarlo o crea uno nuevo.</p>'; return; }
    const cats = CATS.includes(it.categoria) ? CATS : [...CATS, it.categoria];
    const opt = (arr, cur) => arr.map((x) => `<option ${x === cur ? 'selected' : ''}>${esc(x)}</option>`).join('');
    side.innerHTML = `<h3>Panel de Edición</h3><p class="sub">${isNew ? 'Nuevo insumo' : 'Insumo: ' + esc(it.nombre)}</p>
      <div class="field"><label>Nombre del Insumo</label><input id="fNombre" value="${esc(it.nombre)}"></div>
      <div class="field"><label>Categoría</label><select id="fCat">${opt(cats, it.categoria)}</select></div>
      <div class="row2"><div class="field"><label>Stock Actual</label><input id="fStock" type="number" step="0.1" min="0" value="${esc(it.stock)}"></div>
        <div class="field"><label>Stock Mínimo</label><input id="fMin" type="number" step="0.1" min="0" value="${esc(it.min)}"></div></div>
      <div class="row2"><div class="field"><label>Unidad</label><select id="fUni">${opt(UNITS, it.unidad)}</select></div>
        <div class="field"><label>Fecha de Vencimiento</label><input id="fVenc" type="date" value="${esc(it.venc)}"></div></div>
      <div class="field"><label>Responsable Directo</label><input id="fResp" value="${esc(it.responsable)}"></div>
      <div class="field"><label>Estado</label><select id="fEst">${opt(ESTS, it.estado)}</select></div>
      <p class="form-error" id="fErr" hidden></p>
      <div class="btns"><button class="btn btn-primary" id="fSave">Guardar Cambios</button>
        ${isNew ? '' : '<button class="btn btn-danger-soft" id="fDel">Eliminar Insumo</button><button class="btn btn-outline" id="fEnt">Registrar Entrega</button>'}</div>`;
    const auto = () => { $('#fEst').value = autoEstado({ stock: $('#fStock').value, min: $('#fMin').value, venc: $('#fVenc').value }); };
    ['fStock', 'fMin', 'fVenc'].forEach((id) => $('#' + id).addEventListener('input', auto));
    $('#fSave').onclick = () => {
      const d = { nombre: $('#fNombre').value.trim(), categoria: $('#fCat').value, stock: parseFloat($('#fStock').value), min: parseFloat($('#fMin').value),
        unidad: $('#fUni').value, venc: $('#fVenc').value, responsable: $('#fResp').value.trim(), estado: $('#fEst').value };
      const err = (m) => { const e = $('#fErr'); e.textContent = m; e.hidden = false; };
      if (!d.nombre) return err('Ingresa el nombre del insumo.');
      if (!(d.stock >= 0) || !(d.min >= 0)) return err('El stock y el mínimo deben ser números iguales o mayores a 0.');
      if (!d.venc) return err('Indica la fecha de vencimiento.');
      const list = DB.get(K.inv, []);
      const u0 = `${fmtNum(d.stock)} ${d.unidad.toLowerCase()}`;
      if (isNew) {
        const n = { id: uid(), ...d }; list.push(n); st.sel = n.id;
        addMov('entrada', 'Nuevo insumo registrado', `${d.nombre} · ${u0}`, '+' + fmtNum(d.stock));
      } else {
        const o = list.find((x) => x.id === st.sel);
        if (d.stock > o.stock) addMov('entrada', 'Entrada de stock', `${d.nombre} · ${fmtNum(d.stock - o.stock)} ${d.unidad.toLowerCase()}`, '+' + fmtNum(d.stock - o.stock));
        if (d.estado === 'Stock Bajo' && o.estado !== 'Stock Bajo') addMov('alerta', 'Alerta de stock bajo', `${d.nombre} · ${u0}`, 'Bajo');
        if (d.estado === 'Vencido' && o.estado !== 'Vencido') addMov('vencido', 'Producto vencido', `${d.nombre} · ${u0}`, 'Vencido');
        Object.assign(o, d);
      }
      DB.set(K.inv, list); toast('Insumo guardado.'); drawAll();
    };
    if (!isNew) {
      $('#fDel').onclick = () => confirmBox(`¿Eliminar "${esc(it.nombre)}" del inventario?`, () => {
        DB.set(K.inv, DB.get(K.inv, []).filter((x) => x.id !== it.id)); st.sel = null; toast('Insumo eliminado.'); drawAll();
      }, 'Eliminar');
      $('#fEnt').onclick = () => {
        if (it.estado === 'Vencido') return toast('Un producto vencido no puede entregarse.');
        modal({ title: `Registrar entrega · ${it.nombre}`, confirmText: 'Registrar entrega',
          body: `<div class="field"><label>Cantidad (${esc(it.unidad)}) — disponible: ${fmtNum(it.stock)}</label><input id="eCant" type="number" step="0.1" min="0.1"></div>
            <div class="field"><label>Destino</label><select id="eDest"><option>cocina</option><option>pastelería</option><option>panadería</option><option>barra</option></select></div>`,
          onConfirm: (m) => {
            const c = parseFloat($('#eCant', m).value);
            if (!(c > 0)) return 'Ingresa una cantidad mayor a 0.';
            if (c > it.stock) return 'La cantidad supera el stock disponible.';
            const list = DB.get(K.inv, []), o = list.find((x) => x.id === it.id);
            o.stock = Math.round((o.stock - c) * 100) / 100; o.estado = autoEstado(o);
            DB.set(K.inv, list);
            const dest = $('#eDest', m).value, det = `${o.nombre} · ${fmtNum(c)} ${o.unidad.toLowerCase()}`;
            const e = DB.get(K.ent, []); e.push({ id: uid(), destino: dest, detalle: det, ts: new Date().toISOString() }); DB.set(K.ent, e);
            addMov('salida', `Entrega a ${dest}`, det, '−' + fmtNum(c));
            if (o.estado === 'Stock Bajo') addMov('alerta', 'Alerta de stock bajo', `${o.nombre} · ${fmtNum(o.stock)} ${o.unidad.toLowerCase()}`, 'Bajo');
            toast('Entrega registrada. Stock actualizado.'); drawAll();
          } });
      };
    }
  }
  const drawAll = () => { drawTop(); drawTable(); drawLists(); drawSide(); };
  $('#iQ').oninput = (e) => { st.q = e.target.value; drawTable(); };
  $('#iCat').onchange = (e) => { st.cat = e.target.value; drawTable(); };
  $('#iEst').onchange = (e) => { st.est = e.target.value; drawTable(); };
  $('#iNew').onclick = () => { st.sel = 'new'; drawTable(); drawSide(); };
  $('#iBody').addEventListener('click', (e) => { const tr = e.target.closest('tr[data-id]'); if (tr) { st.sel = tr.dataset.id; drawTable(); drawSide(); } });
  drawAll();
}

/* ================= Utensilios y equipos (Encargado/a de cocina) ================= */
function pageUtensilios(u) {
  const v = view(); v.classList.add('flush');
  const st = { tab: 'Todos', est: 'Todos', sel: null };
  v.innerHTML = `<div class="layout"><div class="content">
    <div class="bar-top"><div class="tabs" id="uTabs">${['Todos', 'Utensilios', 'Equipos'].map((t) => `<button data-t="${t}" class="${t === 'Todos' ? 'on' : ''}">${t}</button>`).join('')}</div>
      <div style="display:flex;gap:10px;align-items:center"><span class="pill-static">Sede: ${esc(sedeLabel(u))}</span>
      <select id="uEst" style="width:auto"><option>Estado: Todos</option><option value="Pendiente">Estado: Pendiente</option><option value="Devuelto">Estado: Devuelto</option><option value="Con daños">Estado: Con daños</option></select></div></div>
    <div class="tbl-wrap"><table><thead><tr><th>Código</th><th>Elemento</th><th>Tipo</th><th>Usuario</th><th>Estado</th><th style="text-align:center">Acciones</th></tr></thead><tbody id="uBody"></tbody></table></div>
    </div><aside class="side detail" id="uSide"></aside></div>`;
  const drawTable = () => {
    const rows = DB.get(K.loans, []).filter((l) => (st.tab === 'Todos' || l.tipo + 's' === st.tab) && (st.est === 'Todos' || l.estado === st.est));
    $('#uBody').innerHTML = rows.length ? rows.map((l) => `<tr class="clickable ${st.sel === l.id ? 'sel' : ''}" data-id="${l.id}">
      <td><b>${esc(l.codigo)}</b></td><td>${esc(l.nombre)}</td><td>${esc(l.tipo)}</td><td>${esc(l.usuario)}</td><td>${tag(l.estado)}</td>
      <td style="text-align:center">${l.estado === 'Devuelto' ? '<span style="color:#94a3b8;font-size:12.5px">Sin acciones</span>' : `<button class="btn btn-green" data-rec="${l.id}">Recibir Devolución</button>`}</td></tr>`).join('')
      : '<tr><td colspan="6" class="empty">No hay elementos con ese filtro.</td></tr>';
  };
  const situ = { Pendiente: 'El elemento aún no ha sido devuelto al pañol. El encargado/a puede actualizar el estado una vez recibido.', Devuelto: 'El elemento fue devuelto y está disponible en el pañol.', 'Con daños': 'El elemento tiene daños reportados. Recíbelo para registrar su ingreso al pañol.' };
  const drawSide = () => {
    const l = DB.get(K.loans, []).find((x) => x.id === st.sel), s = $('#uSide');
    if (!l) { s.innerHTML = '<h3>Detalle del elemento</h3><p class="sub">Selecciona un elemento para ver su último préstamo y estado actual.</p>'; return; }
    const c = { Pendiente: 'c-orange', Devuelto: 'c-green', 'Con daños': 'c-red' }[l.estado];
    s.innerHTML = `<h3>Detalle del elemento</h3><p class="sub">Último préstamo y estado actual</p>
      <label class="k">Elemento</label><div class="v">${esc(l.nombre)}</div><div class="s">Código: ${esc(l.codigo)}</div>
      <label class="k">Usuario responsable</label><div class="v">${esc(l.usuario)}</div><div class="s">RUT: ${esc(l.rut)}</div>
      <label class="k">Fechas de préstamo</label><div class="grid2"><div><div class="s">Préstamo</div><div class="v" style="font-size:13.5px">${fmtShort(l.prestamo)}</div></div>
        <div><div class="s">Devolución</div><div class="v ${l.estado === 'Pendiente' ? 'c-red' : ''}" style="font-size:13.5px">${fmtShort(l.devReal || l.devPrevista)}</div></div></div>
      <label class="k">Estado y situación</label><div class="v ${c}">${esc(l.estado)}</div>
      <div class="s">${esc(situ[l.estado])}${l.dano ? `<br><b>Daño reportado:</b> ${esc(l.dano)}` : ''}</div><div class="sep"></div>
      <div class="btns" style="margin-top:0"><button class="btn btn-primary" id="uRec" ${l.estado === 'Devuelto' ? 'disabled' : ''}>Registrar Devolución</button>
      <button class="btn btn-outline" id="uPen" ${l.estado === 'Pendiente' ? 'disabled' : ''}>Marcar como Pendiente</button></div>`;
    $('#uRec').onclick = () => receive(l.id);
    $('#uPen').onclick = () => { const a = DB.get(K.loans, []), o = a.find((x) => x.id === l.id); o.estado = 'Pendiente'; o.devReal = null; DB.set(K.loans, a); toast('Marcado como pendiente.'); draw(); };
  };
  const receive = (id) => { const a = DB.get(K.loans, []), o = a.find((x) => x.id === id); o.estado = 'Devuelto'; o.devReal = new Date().toISOString(); DB.set(K.loans, a); st.sel = id; toast('Devolución registrada.'); draw(); };
  const draw = () => { drawTable(); drawSide(); };
  $('#uTabs').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; st.tab = b.dataset.t; $$('#uTabs button').forEach((x) => x.classList.toggle('on', x === b)); drawTable(); };
  $('#uEst').onchange = (e) => { st.est = e.target.value.startsWith('Estado') ? 'Todos' : e.target.value; drawTable(); };
  $('#uBody').addEventListener('click', (e) => {
    const r = e.target.closest('[data-rec]'); if (r) return receive(r.dataset.rec);
    const tr = e.target.closest('tr[data-id]'); if (tr) { st.sel = tr.dataset.id; draw(); }
  });
  draw();
}

/* ================= Registros de estudiantes (Encargado/a de cocina) ================= */
function pageEstudiantes() {
  const draw = () => {
    const reps = DB.get(K.reports, []).sort((a, b) => b.ts.localeCompare(a.ts));
    view().innerHTML = `<div class="notice"><b>${svg('shield')} Verificación</b><span>Cada reporte es una declaración jurada del estudiante. Revísalo y márcalo como verificado una vez confirmado el estado de los elementos.</span></div>
      <div class="tbl-wrap"><table><thead><tr><th>Fecha</th><th>Estudiante</th><th>Clase</th><th>Elementos</th><th>Alertas de daño</th><th>Estado</th><th></th></tr></thead><tbody>
      ${reps.length ? reps.map((r) => { const dm = r.items.filter((i) => i.dano).length; return `<tr><td>${fmtFull(r.ts)}</td><td><b>${esc(r.estudiante)}</b></td><td>${esc(r.clase)}</td><td>${r.items.length}</td>
        <td class="${dm ? 'c-red' : ''}"><b>${dm}</b></td><td>${r.verificado ? '<span class="tag t-green">Verificado</span>' : '<span class="tag t-amber">Por verificar</span>'}</td>
        <td style="white-space:nowrap"><button class="btn-link" data-ver="${r.id}">Ver detalle</button> ${r.verificado ? '' : `<button class="btn btn-green" data-ok="${r.id}">Verificar</button>`}</td></tr>`; }).join('')
        : '<tr><td colspan="7" class="empty">Aún no hay reportes de estudiantes. Aparecerán aquí cuando envíen su entrega de clase.</td></tr>'}</tbody></table></div>`;
    $$('[data-ver]').forEach((b) => b.onclick = () => {
      const r = reps.find((x) => x.id === b.dataset.ver);
      modal({ title: `Reporte de ${r.estudiante}`, hideCancel: true, confirmText: 'Cerrar', body: `<p style="color:#64748b;margin-bottom:10px">${esc(r.clase)} · ${fmtFull(r.ts)}</p>` +
        r.items.map((i) => `<div class="li"><span class="txt"><b>${esc(i.codigo)} · ${esc(i.nombre)}</b><small>${i.devuelto ? 'Devuelto' : 'No devuelto'}${i.dano ? ' · Con daños: ' + esc(i.desc) : ''}</small></span></div>`).join('') });
    });
    $$('[data-ok]').forEach((b) => b.onclick = () => {
      const a = DB.get(K.reports, []), r = a.find((x) => x.id === b.dataset.ok); r.verificado = true; DB.set(K.reports, a); toast('Reporte verificado.'); draw();
    });
  };
  draw();
}

/* ================= Consumo (Administrador/a y Docente) ================= */
function pageConsumo() {
  const data = DB.get(K.consumo, { cursos: [], filas: [] });
  const st = { q: '', curso: 'Todos', receta: 'Todos', per: 'Semestre Otoño 2026' };
  const fmtLong = (iso) => { const [y, m, d] = iso.split('-'); return `${d} ${MESES[+m - 1]} ${y}`; };
  view().innerHTML = `<div class="notice"><b>${svg('shield')} Permisos de acceso</b><span>Esta vista muestra consolidado por curso y por receta. Administrador/a de sede puede consultar Inicio, Consumo y Presupuesto. Docente también puede consultar Consumo para revisar recetas, insumos y clases asignadas.</span></div>
    <div class="kpis" id="cKpis"></div>
    <div class="card"><div class="toolbar"><div class="search">${svg('search')}<input id="cQ" placeholder="Buscar por curso, receta, docente o fecha de clase..."></div>
      <button class="btn btn-primary" id="cExp">${svg('plus')} Exportar Consolidado</button></div>
      <div class="filters"><select id="cCurso"></select><select id="cRec"></select><select id="cPer"><option>Semestre Otoño 2026</option><option>Semestre Primavera 2025</option></select></div></div>
    <div class="card"><h3>Consumo por Curso</h3><div class="bars" id="cBars"></div></div>
    <div class="tbl-wrap"><table><thead><tr><th>Curso</th><th>Receta</th><th>Fecha de Clase</th><th>Insumos Utilizados</th><th>Cantidad Utilizada</th><th>Historial de Clases</th><th>Docente Responsable</th><th>Estado</th></tr></thead><tbody id="cBody"></tbody></table></div>`;
  $('#cCurso').innerHTML = ['Todos', ...data.cursos.map((c) => c.nombre)].map((c) => `<option value="${esc(c)}">Curso: ${esc(c)}</option>`).join('');
  $('#cRec').innerHTML = ['Todos', ...new Set(data.filas.map((f) => f.receta))].map((c) => `<option value="${esc(c)}">Receta: ${c === 'Todos' ? 'Todos los Talleres' : esc(c)}</option>`).join('');
  const filtered = () => {
    if (st.per !== 'Semestre Otoño 2026') return { cursos: [], filas: [] };
    const q = st.q.toLowerCase();
    const filas = data.filas.filter((f) => (st.curso === 'Todos' || f.cursoFull === st.curso) && (st.receta === 'Todos' || f.receta === st.receta)
      && (!q || `${f.curso} ${f.cursoFull} ${f.receta} ${f.docente} ${fmtLong(f.fecha)} ${fmtDate(f.fecha)}`.toLowerCase().includes(q)));
    const cursos = data.cursos.filter((c) => (st.curso === 'Todos' || c.nombre === st.curso) && (!q || filas.some((f) => f.cursoFull === c.nombre)));
    return { cursos, filas };
  };
  const draw = () => {
    const { cursos, filas } = filtered();
    const crit = DB.get(K.inv, []).filter((i) => i.estado !== 'Disponible').length;
    $('#cKpis').innerHTML = kpi('Cursos con consumo activo', `${cursos.length} cursos`, 'c-blue', `${filas.filter((f) => f.estado === 'Excedido').length} con desviación superior a 10%`)
      + kpi('Recetas realizadas', `${cursos.reduce((s, c) => s + c.rec, 0)} recetas`, 'c-orange', `${filas.length} recetas con historial de clases`)
      + kpi('Insumos utilizados', `${filas.reduce((s, f) => s + f.insumos, 0)} insumos`, 'c-red', `${crit} insumos críticos en seguimiento`)
      + kpi('Consumo total', `${fmtNum(cursos.reduce((s, c) => s + c.kg, 0))} kg`, 'c-green', 'Acumulado del período seleccionado');
    const max = Math.max(1, ...cursos.map((c) => c.kg));
    $('#cBars').innerHTML = cursos.length ? cursos.map((c) => `<div class="b"><div class="b-head"><b>${esc(c.nombre)}</b><span>${c.est} estudiantes · ${c.rec} recetas · ${fmtNum(c.kg)} kg consumidos</span></div><div class="track"><div class="fill" style="width:${(c.kg / max * 100).toFixed(1)}%;background:${c.color}"></div></div></div>`).join('') : '<p class="empty">Sin datos para el filtro seleccionado.</p>';
    $('#cBody').innerHTML = filas.length ? filas.map((f) => `<tr><td><b>${esc(f.curso)}</b></td><td>${esc(f.receta)}</td><td>${fmtLong(f.fecha)}</td><td>${f.insumos} insumos</td><td class="num">${fmtNum(f.kg)} kg</td><td>${f.clases} clases realizadas</td><td>${esc(f.docente)}</td><td>${tag(f.estado)}</td></tr>`).join('') : '<tr><td colspan="8" class="empty">No hay registros de consumo para este filtro.</td></tr>';
  };
  $('#cQ').oninput = (e) => { st.q = e.target.value; draw(); };
  $('#cCurso').onchange = (e) => { st.curso = e.target.value; draw(); };
  $('#cRec').onchange = (e) => { st.receta = e.target.value; draw(); };
  $('#cPer').onchange = (e) => { st.per = e.target.value; draw(); };
  $('#cExp').onclick = () => {
    const { filas } = filtered();
    if (!filas.length) return toast('No hay datos para exportar.');
    const head = ['Curso', 'Receta', 'Fecha', 'Insumos', 'Cantidad (kg)', 'Clases', 'Docente', 'Estado'];
    download('consumo_consolidado.csv', [head, ...filas.map((f) => [f.cursoFull, f.receta, fmtDate(f.fecha), f.insumos, f.kg, f.clases, f.docente, f.estado])].map((r) => r.map(csvCell).join(';')).join('\n'));
    toast('Consolidado exportado.');
  };
  draw();
}

/* ================= Presupuesto (Administrador/a de sede) ================= */
function pagePresupuesto(u) {
  $('#pageSub').textContent = `Vista exclusiva para Administrador/a de sede · ${sedeLabel(u)}`;
  const st = { q: '', mes: '', tipo: 'Todos', resp: 'Todos' };
  view().innerHTML = `<div class="notice"><b>${svg('shield')} Acceso restringido · Administrador/a de sede</b><span>Esta vista muestra el presupuesto actual de Gastronomía, su evolución y el historial de movimientos disponibles únicamente para el rol Administrador/a de sede.</span></div>
    <div class="kpis" id="pKpis"></div>
    <div class="card"><div class="toolbar"><div class="search">${svg('search')}<input id="pQ" placeholder="Buscar movimiento, N° orden, factura, responsable..."></div>
      <button class="btn btn-primary" id="pNew">${svg('plus')} Registrar movimiento</button><button class="btn btn-outline" id="pHist">${svg('download')} Consultar historial</button></div>
      <div class="filters"><select id="pMes"></select><select id="pTipo"><option value="Todos">Tipo: Todos los Movimientos</option><option>Ingreso</option><option>Egreso</option></select><select id="pResp"></select></div></div>
    <div class="tbl-wrap"><table><thead><tr><th>Fecha</th><th>Descripción</th><th>Tipo</th><th class="r">Monto</th><th class="r">Saldo</th><th>Acción</th></tr></thead><tbody id="pBody"></tbody></table></div>`;
  const withSaldo = () => {
    const b = DB.get(K.budget, { inicial: 0, movs: [] });
    let s = b.inicial;
    const sorted = [...b.movs].sort((a, c) => a.ts.localeCompare(c.ts)).map((m) => { s += m.tipo === 'Ingreso' ? m.monto : -m.monto; return { ...m, saldo: s }; });
    return { b, rows: sorted.reverse() };
  };
  const fillFilters = () => {
    const { rows } = withSaldo();
    const meses = [...new Set(rows.map((r) => r.ts.slice(0, 7)))];
    const now = isoDay().slice(0, 7);
    if (!st.mes) st.mes = meses.includes(now) ? now : 'Todos';
    $('#pMes').innerHTML = `<option value="Todos">Filtro Fecha: Todos</option>` + meses.map((m) => `<option value="${m}">Filtro Fecha: ${MESES_L[+m.slice(5) - 1]} ${m.slice(0, 4)}</option>`).join('');
    $('#pMes').value = st.mes;
    const resps = [...new Set(rows.map((r) => r.resp))];
    $('#pResp').innerHTML = `<option value="Todos">Responsable: Todos</option>` + resps.map((r) => `<option>${esc(r)}</option>`).join('');
    $('#pResp').value = resps.includes(st.resp) ? st.resp : 'Todos';
  };
  const draw = () => {
    fillFilters();
    const { b, rows } = withSaldo(), s = budgetStats(b), q = st.q.toLowerCase();
    $('#pKpis').innerHTML = kpi('Presupuesto actual', clp(s.actual), 'c-blue', 'Disponible para compras inmediatas')
      + kpi('Presupuesto inicial', clp(b.inicial), 'c-blue', 'Aprobado por el Ministerio de Educación')
      + kpi('Gastos', clp(s.gastos), 'c-orange', 'Órdenes de compra de insumos en tránsito')
      + kpi('Ingresos / asignaciones', clp(s.ingresos), 'c-green', 'Reposición de caja chica y asignaciones vigentes');
    const list = rows.filter((r) => (st.mes === 'Todos' || r.ts.startsWith(st.mes)) && (st.tipo === 'Todos' || r.tipo === st.tipo)
      && (st.resp === 'Todos' || r.resp === st.resp) && (!q || `${r.desc} ${r.resp} ${r.tipo}`.toLowerCase().includes(q)));
    $('#pBody').innerHTML = list.length ? list.map((r) => `<tr><td style="color:#64748b;white-space:nowrap">${fmtShort(r.ts).replace(/^(\d+ \w+), /, '$1, ')}</td><td><b>${esc(r.desc)}</b></td><td>${tag(r.tipo)}</td>
      <td class="r num ${r.tipo === 'Ingreso' ? 'c-green' : ''}">${clpSigned(r.tipo === 'Ingreso' ? r.monto : -r.monto)}</td><td class="r" style="color:#64748b">${clp(r.saldo)}</td>
      <td><button class="btn-link" data-ed="${r.id}">Editar</button></td></tr>`).join('') : '<tr><td colspan="6" class="empty">No hay movimientos para este filtro.</td></tr>';
    $$('[data-ed]').forEach((bt) => bt.onclick = () => form(b.movs.find((m) => m.id === bt.dataset.ed)));
  };
  const form = (m) => {
    const isNew = !m;
    const mm = m || { ts: isoLocal(), desc: '', tipo: 'Egreso', monto: '' };
    const box = modal({ title: isNew ? 'Registrar movimiento' : 'Editar movimiento', confirmText: 'Guardar movimiento',
      body: `<div class="field"><label>Fecha y hora</label><input id="mTs" type="datetime-local" value="${esc(mm.ts)}"></div>
        <div class="field"><label>Descripción</label><input id="mDesc" value="${esc(mm.desc)}" placeholder="Ej: Factura Proveedor - Insumos"></div>
        <div class="row2"><div class="field"><label>Tipo</label><select id="mTipo"><option ${mm.tipo === 'Egreso' ? 'selected' : ''}>Egreso</option><option ${mm.tipo === 'Ingreso' ? 'selected' : ''}>Ingreso</option></select></div>
        <div class="field"><label>Monto (CLP)</label><input id="mMonto" type="number" min="1" step="1" value="${esc(mm.monto)}"></div></div>
        ${isNew ? '' : '<button type="button" class="btn btn-danger-soft btn-sm" id="mDel">Eliminar movimiento</button>'}`,
      onConfirm: (bx) => {
        const d = { ts: $('#mTs', bx).value, desc: $('#mDesc', bx).value.trim(), tipo: $('#mTipo', bx).value, monto: Math.round(parseFloat($('#mMonto', bx).value)) };
        if (!d.ts) return 'Indica la fecha del movimiento.';
        if (!d.desc) return 'Escribe una descripción.';
        if (!(d.monto > 0)) return 'El monto debe ser mayor a 0.';
        const b = DB.get(K.budget, { inicial: 0, movs: [] });
        if (isNew) b.movs.push({ id: uid(), ...d, resp: fullName(u) }); else Object.assign(b.movs.find((x) => x.id === m.id), d);
        DB.set(K.budget, b); st.mes = 'Todos'; toast('Movimiento guardado.'); draw();
      } });
    if (!isNew) $('#mDel', box).onclick = () => confirmBox('¿Eliminar este movimiento del historial?', () => {
      const b = DB.get(K.budget, { inicial: 0, movs: [] }); b.movs = b.movs.filter((x) => x.id !== m.id); DB.set(K.budget, b); box.remove(); toast('Movimiento eliminado.'); draw();
    }, 'Eliminar');
  };
  $('#pQ').oninput = (e) => { st.q = e.target.value; draw(); };
  $('#pMes').onchange = (e) => { st.mes = e.target.value; draw(); };
  $('#pTipo').onchange = (e) => { st.tipo = e.target.value; draw(); };
  $('#pResp').onchange = (e) => { st.resp = e.target.value; draw(); };
  $('#pNew').onclick = () => form(null);
  $('#pHist').onclick = () => {
    const { rows } = withSaldo();
    download('historial_presupuesto.csv', [['Fecha', 'Descripción', 'Tipo', 'Monto CLP', 'Saldo CLP', 'Responsable'], ...rows.map((r) => [r.ts.replace('T', ' '), r.desc, r.tipo, r.tipo === 'Ingreso' ? r.monto : -r.monto, r.saldo, r.resp])].map((r) => r.map(csvCell).join(';')).join('\n'));
    toast('Historial descargado.');
  };
  draw();
}

/* ================= Módulo Estudiante: reporte de entrega ================= */
function pageRegistroUtensilios(u) {
  const CLASES = ['Taller de Repostería Básica', 'Taller de Panadería', 'Cocina Fría', 'Cocina Caliente'];
  const st = { clase: CLASES[0], items: {} };
  const myLoans = () => DB.get(K.loans, []).filter((l) => cleanRut(l.rut) === u.rut && l.estado === 'Pendiente');
  const sync = () => myLoans().forEach((l) => { if (!st.items[l.id]) st.items[l.id] = { dev: true, dano: false, desc: '' }; });
  view().innerHTML = `<div class="stu"><div>
      <div class="card" style="padding:20px 24px"><div class="info-grid">
        <div><small>Estudiante</small><b>${esc(fullName(u))}</b></div><div><small>Fecha y hora sistema</small><b id="sHora"></b></div>
        <div><small>Clase gastronómica</small><select id="sClase">${CLASES.map((c) => `<option>${esc(c)}</option>`).join('')}</select></div>
        <div><small>Retorno previsto</small><b id="sRet"></b></div></div></div>
      <div class="card"><h3 style="margin-bottom:4px">Registro de utensilios y equipos</h3>
        <p style="color:#64748b;font-size:13px;margin-bottom:6px">Marque el estado de cada elemento recibido al finalizar la clase.</p>
        <div id="sItems"></div>
        <div class="add-row"><select id="sCat"></select><button class="btn btn-outline btn-sm" id="sAdd">${svg('plus')} Declarar elemento</button></div></div></div>
    <aside class="card"><h3 style="margin-bottom:2px">Resumen de registro</h3><p style="color:#94a3b8;font-size:12.5px;padding-bottom:14px;border-bottom:1px solid var(--line)">Validación académica digital</p>
      <div style="margin-top:8px" id="sSum"></div>
      <div class="declar"><b>DECLARACIÓN JURADA ACADÉMICA:</b>Al enviar este formulario, usted asume la responsabilidad del estado de entrega. Su reporte será verificado por el Encargado de Cocina de la Sede.</div>
      <button class="btn btn-primary btn-block" style="height:48px" id="sSend">Enviar y generar reporte</button></aside></div>`;
  const clock = () => { const now = new Date().toISOString(); $('#sHora').textContent = `${fmtFull(now).replace(' · ', ' · ')}`; };
  const retorno = () => { const n = new Date(); const r = n.getHours() < 13 ? atTime(13, 0) : isoLocal(new Date(n.getTime() + 2 * 3600e3)); $('#sRet').textContent = fmtFull(r); return r; };
  clock(); const ret = retorno(); setInterval(clock, 30000);

  function drawItems() {
    sync();
    const loans = myLoans();
    $('#sItems').innerHTML = loans.length ? loans.map((l) => { const s = st.items[l.id]; const noDev = !s.dev;
      return `<div class="item" data-id="${l.id}">
        <div><div class="code">${esc(l.codigo)}</div><div class="name">${esc(l.nombre)}</div></div>
        <div class="dates"><b>Fecha de préstamo</b>${fmtFull(l.prestamo).replace(' · ', ' · ')}<div class="dd"><b>Fecha de devolución</b>${fmtFull(l.devPrevista)}</div></div>
        <div class="pills"><button class="pill ${s.dev ? 'on' : ''}" data-a="dev1">Devuelto</button><button class="pill ${!s.dev ? 'on' : ''}" data-a="dev0">No devuelto</button>
          <button class="pill bad ${s.dano && !noDev ? 'on' : ''}" data-a="dano1" ${noDev ? 'disabled' : ''}>Con daños</button><button class="pill ${!s.dano || noDev ? 'on' : ''}" data-a="dano0" ${noDev ? 'disabled' : ''}>Sin daños</button></div>
        <div class="dmg ${s.dano && !noDev ? 'bad' : ''}"><div class="dmg-label">Describa el daño del elemento culinario:</div>
          <textarea data-d ${s.dano && !noDev ? '' : 'disabled'} placeholder="${s.dano && !noDev ? 'Describa qué le ocurrió al elemento…' : 'No aplica'}">${esc(s.dano && !noDev ? s.desc : '')}</textarea></div></div>`; }).join('')
      : '<p class="empty">No tienes elementos pendientes. Usa “Declarar elemento” para registrar lo que recibiste en clase.</p>';
    const arr = loans.filter((l) => st.items[l.id]);
    $('#sSum').innerHTML = `<div class="sum-row">Utensilios declarados<b>${arr.filter((l) => l.tipo === 'Utensilio').length} elementos</b></div>
      <div class="sum-row">Equipos declarados<b>${arr.filter((l) => l.tipo === 'Equipo').length} elemento${arr.filter((l) => l.tipo === 'Equipo').length === 1 ? '' : 's'}</b></div>
      <div class="sum-row">Alertas de daño<b class="${arr.some((l) => st.items[l.id].dano && st.items[l.id].dev) ? 'red' : ''}">${arr.filter((l) => st.items[l.id].dano && st.items[l.id].dev).length} reportado${arr.filter((l) => st.items[l.id].dano && st.items[l.id].dev).length === 1 ? '' : 's'}</b></div>`;
    const taken = DB.get(K.loans, []).filter((l) => l.estado === 'Pendiente').map((l) => l.codigo);
    const free = DB.get(K.catalog, []).filter((c) => !taken.includes(c.codigo));
    $('#sCat').innerHTML = free.length ? free.map((c) => `<option value="${esc(c.codigo)}">${esc(c.codigo)} · ${esc(c.nombre)}</option>`).join('') : '<option value="">No hay elementos disponibles</option>';
    $('#sAdd').disabled = !free.length;
  }
  $('#sClase').onchange = (e) => { st.clase = e.target.value; };
  $('#sItems').addEventListener('click', (e) => {
    const b = e.target.closest('[data-a]'); if (!b) return;
    const s = st.items[b.closest('.item').dataset.id];
    ({ dev1: () => { s.dev = true; }, dev0: () => { s.dev = false; s.dano = false; s.desc = ''; }, dano1: () => { s.dano = true; }, dano0: () => { s.dano = false; s.desc = ''; } })[b.dataset.a]();
    drawItems();
  });
  $('#sItems').addEventListener('input', (e) => { if (e.target.matches('[data-d]')) st.items[e.target.closest('.item').dataset.id].desc = e.target.value; });
  $('#sAdd').onclick = () => {
    const code = $('#sCat').value, c = DB.get(K.catalog, []).find((x) => x.codigo === code); if (!c) return;
    const a = DB.get(K.loans, []);
    a.push({ id: uid(), codigo: c.codigo, nombre: c.nombre, tipo: c.tipo, usuario: fullName(u), rut: formatRut(u.rut), estado: 'Pendiente', dano: '', prestamo: isoLocal(), devPrevista: ret, devReal: null });
    DB.set(K.loans, a); toast('Elemento declarado.'); drawItems();
  };
  $('#sSend').onclick = () => {
    const loans = myLoans();
    if (!loans.length) return toast('No hay elementos para reportar.');
    for (const l of loans) { const s = st.items[l.id]; if (s.dev && s.dano && s.desc.trim().length < 5) return toast(`Describe el daño de ${l.codigo} (mínimo 5 caracteres).`); }
    const now = new Date().toISOString();
    const all = DB.get(K.loans, []);
    const items = loans.map((l) => {
      const s = st.items[l.id], o = all.find((x) => x.id === l.id);
      if (s.dev) { o.estado = s.dano ? 'Con daños' : 'Devuelto'; o.dano = s.dano ? s.desc.trim() : ''; o.devReal = now; } else { o.estado = 'Pendiente'; }
      return { codigo: l.codigo, nombre: l.nombre, tipo: l.tipo, devuelto: s.dev, dano: s.dev && s.dano, desc: s.dev && s.dano ? s.desc.trim() : '' };
    });
    DB.set(K.loans, all);
    const rep = { id: uid(), ts: now, rut: u.rut, estudiante: fullName(u), clase: st.clase, items, verificado: false };
    const reps = DB.get(K.reports, []); reps.push(rep); DB.set(K.reports, reps);
    st.items = {};
    const txt = [`REPORTE DE ENTREGA DE CLASE`, `Estudiante: ${rep.estudiante} (${formatRut(u.rut)})`, `Clase: ${rep.clase}`, `Fecha: ${fmtFull(now)}`, `Sede: ${sedeLabel(u)}`, '',
      ...items.map((i) => `- ${i.codigo} ${i.nombre}: ${i.devuelto ? 'Devuelto' : 'NO devuelto'}${i.dano ? ` · CON DAÑOS: ${i.desc}` : i.devuelto ? ' · Sin daños' : ''}`), '',
      'Declaración jurada académica: el estudiante asume la responsabilidad del estado de entrega. Sujeto a verificación del Encargado de Cocina.'].join('\n');
    modal({ title: 'Reporte generado', confirmText: 'Descargar reporte', cancelText: 'Cerrar',
      body: `<pre style="white-space:pre-wrap;font:12.5px/1.5 var(--font);background:#f8fafc;border:1px solid var(--line);border-radius:8px;padding:12px">${esc(txt)}</pre>`,
      onConfirm: () => { download('reporte_entrega_clase.txt', txt, 'text/plain;charset=utf-8'); } });
    drawItems();
  };
  drawItems();
}

/* ================= Arranque ================= */
const PAGES = {
  inicio: pageInicio, consumo: pageConsumo, presupuesto: pagePresupuesto, insumos: pageInsumos,
  utensilios: pageUtensilios, estudiantes: pageEstudiantes, 'registro-utensilios': pageRegistroUtensilios,
};
async function init() {
  await seed();
  const page = document.body.dataset.page;
  if (page === 'login') return initLogin();
  if (page === 'registro') return initRegistro();
  const u = currentUser();
  if (!u) { location.replace('/login/'); return; }
  if (!NAV[u.rol].some((n) => n[0] === page)) { location.replace('/inicio/'); return; }
  buildShell(u);
  PAGES[page](u);
}
document.addEventListener('DOMContentLoaded', init);
})();
