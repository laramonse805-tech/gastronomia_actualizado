"""Utilidades de RUT chileno (módulo 11)."""
import re


def limpiar(rut: str) -> str:
    """Quita puntos y espacios, y pasa la K a mayúscula."""
    return re.sub(r"[.\s]", "", rut or "").upper()


def digito_verificador(cuerpo: str) -> str:
    suma, mult = 0, 2
    for d in reversed(cuerpo):
        suma += int(d) * mult
        mult = 2 if mult == 7 else mult + 1
    r = 11 - (suma % 11)
    return "0" if r == 11 else "K" if r == 10 else str(r)


def es_valido(rut: str) -> bool:
    rut = limpiar(rut)
    m = re.fullmatch(r"(\d{7,8})-([\dK])", rut)
    return bool(m) and digito_verificador(m.group(1)) == m.group(2)


def formatear(rut: str) -> str:
    rut = limpiar(rut)
    m = re.fullmatch(r"(\d{7,8})-([\dK])", rut)
    if not m:
        return rut
    cuerpo = f"{int(m.group(1)):,}".replace(",", ".")
    return f"{cuerpo}-{m.group(2)}"
